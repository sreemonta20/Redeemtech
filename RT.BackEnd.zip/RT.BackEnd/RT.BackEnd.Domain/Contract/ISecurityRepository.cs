﻿using RT.BackEnd.Domain.DTO;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RT.BackEnd.Domain.Contract
{
    public interface ISecurityRepository
    {
        Task<object> AuthenticateUser(dtoUserAuthReq oAuthReq);
        object GetSignoutCommand();
    }
}
