﻿using AutoMapper;
using RT.BackEnd.Domain.DTO;
using RT.BackEnd.Persistence.DBModel;
using System;
using System.Collections.Generic;
using System.Runtime;
using System.Text;

namespace RT.BackEnd.Domain.AutoMapping
{
    public class AllModelsMapper: Profile
    {
        public AllModelsMapper()
        {
            CreateMap<LoginUser, dtoLoginUser>();
            CreateMap<dtoLoginUser, LoginUser>();
            CreateMap<MovieDetails, dtoMovieDetails>();
            CreateMap<dtoMovieDetails, MovieDetails>();

        }
    }
}
