﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RT.BackEnd.Domain.DTO
{
    public class dtoUserAuthReq
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
