﻿using System;

namespace RT.BackEnd.Common.Utilities
{
    public static class ConnectionParameter
    {
        public static String MainConnName;
        public static String MainConnection;
        public static String MainProvider;

    }
}
