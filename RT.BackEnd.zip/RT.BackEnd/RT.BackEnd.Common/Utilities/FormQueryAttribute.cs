﻿using System;

namespace RT.BackEnd.Common.Utilities
{
    public class FormQueryAttribute : Attribute
    {
    }
}
