﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RT.BackEnd.Common.Utilities
{
    public class StoredProcedureDeposit
    {
        
        public const string SpGet_UILogin = "[dbo].[uspGetUIConfiguration]";

    }
}
