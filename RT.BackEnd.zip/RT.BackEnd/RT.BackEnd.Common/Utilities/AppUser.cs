﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RT.BackEnd.Common.Utilities
{
    public static class AppUser
    {
        private static int? appUserCode;
        private static string appUserId;
        private static string appUserName;
        private static bool appIsLoggedIn;

        public static int? AppUserCode { get => appUserCode; set => appUserCode = value; }
        public static string AppUserId { get => appUserId; set => appUserId = value; }
        public static string AppUserName { get => appUserName; set => appUserName = value; }
        public static bool AppIsLoggedIn { get => appIsLoggedIn; set => appIsLoggedIn = value; }
    }
}
