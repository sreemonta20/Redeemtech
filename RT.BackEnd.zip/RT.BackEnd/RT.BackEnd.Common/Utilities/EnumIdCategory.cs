﻿using System;

namespace CommonModel
{
    public enum EnumIdCategory
    {
        //ProductId = 1
        WorkingUnitId = 2
    }
}
