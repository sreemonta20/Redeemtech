export class ApiConst {
  constructor() { }
  autohost(domain) {
      let apiHost = '';

      apiHost  = 'http://localhost:3296/api/';
      return apiHost;
  }
}
